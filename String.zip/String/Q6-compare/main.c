
#include<stdio.h>
int main()
{
    char string1[1000],string2[1000];
    int value;
    printf("enter the first word");
    gets(string1);
    printf("enter the second word");
    gets(string2);
    value=strcmp(string1,string2);

    if(value==-1)
    {
        printf("the first word comes first in alphabetical order");
    }
        else if(value==1){
            printf("the second word comes first in alpahbetical order\n");
        }

        else
        {
            printf("the second and first words are in same in alpahbetical order\n");
        }
    }

