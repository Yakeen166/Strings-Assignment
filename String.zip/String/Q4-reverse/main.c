#include <stdio.h>
int main()
{
    char string[1000];
    int length,i;
    printf("enter the sentence:");
    gets(string);
    length=strlen(string);
    for(i=length-1;i>=0;i--)
    {
     printf("%c",string[i]);
    printf("\t");
     }
}


