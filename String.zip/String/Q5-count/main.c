#include<stdio.h>
#include <stdio.h>
int main()
{
    int string[100];
    int length;
    printf("enter the name");
    gets(string);

    length=strlen(string);
    printf("the number of letter is the %d",length);
}
