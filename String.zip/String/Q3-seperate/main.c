#include<stdio.h>
#include <stdlib.h>


int main()
{
   char string[100];
   int i= 0;

      printf("Input the string : ");
      gets(string);

      printf("The characters of the string are : \n");
   while(string[i]!='\0')
   {
      printf("%c  ", string[i]);
      i++;
   }
   printf("\n");
}
